
package tisetso;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Quikmassege {

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;
    private String messageStatus;

    private static ArrayList<Quikmassege> sentMessages =
            new ArrayList<>();

    private static ArrayList<Quikmassege> disregardedMessages =
            new ArrayList<>();

    private static ArrayList<Quikmassege> storedMessages =
            new ArrayList<>();

    private static int totalMessages = 0;

    // CONSTRUCTOR
    public Quikmassege(
            String messageID,
            int messageNumber,
            String recipient,
            String message) {

        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.recipient = recipient;
        this.message = message;

        this.messageHash = createMessageHash();
    }

    // START QUICKCHAT
    public static void startQuickChat(Scanner input) {

        System.out.println("How many messages would you like to enter?");

        int numberOfMessages;

        while (true) {

            try {

                numberOfMessages = Integer.parseInt(input.nextLine());

                if (numberOfMessages >= 0) {
                    break;
                }

                System.out.println("Enter a valid number.");

            } catch (NumberFormatException e) {

                System.out.println("Please enter a number.");
            }
        }

        boolean running = true;

        while (running) {

            System.out.println("\n====================");
            System.out.println("     QUICKCHAT");
            System.out.println("====================");

            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Stored Messages");
            System.out.println("4. Quit");

            System.out.print("Choose an option: ");

            String option = input.nextLine();

            switch (option) {

                case "1":

                    Message(input, numberOfMessages);
                    break;

                case "2":

                    System.out.println(printMessages());
                    break;

                case "3":

                    storeMasseges.storedMessagesMenu(input);
                    break;

                case "4":

                    running = false;
                    System.out.println("Thank you for using QuickChat.");
                    break;

                default:

                    System.out.println("Invalid option.");
            }
        }
    }

    // SEND MESSAGES
    public static void Message(
            Scanner input,
            int numberOfMessages) {

        for (int i = 1; i <= numberOfMessages; i++) {

            System.out.println("\nMessage " + i);

            String messageID = generateMessageID();

            System.out.println("Message ID: " + messageID);

            String recipient;

            while (true) {

                System.out.println("Enter recipient cellphone number:");
                recipient = input.nextLine();

                Quikmassege temporaryMessage =
                        new Quikmassege(messageID, i, recipient, "");

                if (temporaryMessage.checkRecipientCell()) {

                    System.out.println("Cellphone number successfully captured.");
                    break;

                } else {

                    System.out.println("Invalid cellphone number.");
                    System.out.println("Use an international number, e.g. +27123456789.");
                }
            }

            String messageText;

            while (true) {

                System.out.println("Enter your message:");
                messageText = input.nextLine();

                if (messageText.length() <= 250) {

                    System.out.println("Message ready to send.");
                    break;

                } else {

                    System.out.println("Message must not exceed 250 characters.");
                }
            }

            Quikmassege newMessage =
                    new Quikmassege(
                            messageID,
                            i,
                            recipient,
                            messageText
                    );

            System.out.println("Message Hash: "
                    + newMessage.messageHash);

            String result = newMessage.SentMessage(input);

            System.out.println(result);

            if ("Sent".equals(newMessage.messageStatus)) {

                System.out.println("\nMessage ID: "
                        + newMessage.messageID);

                System.out.println("Message Hash: "
                        + newMessage.messageHash);

                System.out.println("Recipient: "
                        + newMessage.recipient);

                System.out.println("Message: "
                        + newMessage.message);
            }
        }

        System.out.println("Total messages sent: "
                + returnTotalMessages());
    }

    // CHECK RECIPIENT NUMBER
    public boolean checkRecipientCell() {

        return recipient != null
                && recipient.matches("\\+[1-9][0-9]{7,14}");
    }

    // CREATE MESSAGE HASH
    public String createMessageHash() {

        String firstTwoNumbers = messageID.substring(0, 2);

        String firstWord = "";
        String lastWord = "";

        if (message != null && !message.trim().isEmpty()) {

            String[] words = message.trim().split("\\s+");

            firstWord = words[0];
            lastWord = words[words.length - 1];

            firstWord = firstWord.replaceAll("[^a-zA-Z0-9]", "");
            lastWord = lastWord.replaceAll("[^a-zA-Z0-9]", "");
        }

        return (firstTwoNumbers + ":"
                + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // GENERATE MESSAGE ID
    public static String generateMessageID() {

        Random random = new Random();

        String id = "";

        for (int i = 0; i < 10; i++) {

            id = id + random.nextInt(10);
        }

        return id;
    }

    // CHECK MESSAGE ID
    public boolean checkMessageID() {

        return messageID != null
                && messageID.length() <= 10;
    }

    // CHECK MESSAGE LENGTH
    public String checkMessageLength() {

        if (message.length() <= 250) {

            return "Message ready to send.";

        } else {

            int extra = message.length() - 250;

            return "Message exceeds 250 characters by "
                    + extra + ", please reduce the size.";
        }
    }

    // SENT MESSAGE MENU
    public String SentMessage(Scanner input) {

        String choice;

        while (true) {

            System.out.println("\n1. Send Message");
            System.out.println("2. Disregard Message");
            System.out.println("3. Store Message to send later");

            System.out.print("Choose an option: ");

            choice = input.nextLine();

            if (choice.equals("1")
                    || choice.equals("2")
                    || choice.equals("3")) {

                break;

            } else {

                System.out.println("Invalid option.");
            }
        }

        return SentMessage(choice);
    }

    // PROCESS MESSAGE
    public String SentMessage(String choice) {

        switch (choice) {

            case "1":

                messageStatus = "Sent";

                sentMessages.add(this);

                totalMessages++;

                storeMasseges.addMassege(
                        messageID,
                        messageHash,
                        recipient,
                        message,
                        messageStatus
                );

                return "Message successfully sent.";

            case "2":

                messageStatus = "Disregarded";

                disregardedMessages.add(this);

                storeMasseges.addMassege(
                        messageID,
                        messageHash,
                        recipient,
                        message,
                        messageStatus
                );

                return "Message successfully disregarded.";

            case "3":

                messageStatus = "Stored";

                storedMessages.add(this);

                storeMasseges.addMassege(
                        messageID,
                        messageHash,
                        recipient,
                        message,
                        messageStatus
                );

                return "Message successfully stored.";

            default:

                return "Invalid option.";
        }
    }

    // PRINT SENT MESSAGES
    public static String printMessages() {

        String allMessages = "";

        for (Quikmassege sent : sentMessages) {

            allMessages +=
                    "Message ID: " + sent.messageID + "\n"
                    + "Message Hash: " + sent.messageHash + "\n"
                    + "Recipient: " + sent.recipient + "\n"
                    + "Message: " + sent.message + "\n\n";
        }

        if (allMessages.isEmpty()) {
            return "No messages have been sent.";
        }

        return allMessages;
    }

    // RETURN TOTAL MESSAGES
    public static int returnTotalMessages() {

        return totalMessages;
    }
}
